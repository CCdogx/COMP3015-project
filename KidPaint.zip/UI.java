import javax.swing.*;
import javax.swing.border.LineBorder;
import java.awt.*;
import java.awt.event.*;
import java.util.LinkedList;
import java.util.List;

enum PaintMode {Pixel, Area};

public class UI extends JFrame {
    private JTextField msgField;
    private JTextField studioField;
    private JTextArea chatArea;
    private JTextArea studio;
    private JPanel pnlColorPicker;
    private JPanel paintPanel;
    private JToggleButton tglPen;
    private JToggleButton tglBucket;
    private JToggleButton tglSave;
    private JToggleButton tglLoad;

    private JToggleButton tglClearOnline;
    private JToggleButton tglpyramind1;
    private JToggleButton tglpyramind2;
    private JToggleButton tglsquare;
    private static UI instance;
    private int selectedColor = 2156005;    //golden

    int[][] data = new int[50][50];            // pixel color data array
    int blockSize = 20;
    PaintMode paintMode = PaintMode.Pixel;

    /**
     * get the instance of UI. Singleton design pattern.
     *
     * @return
     */
    public static UI getInstance() {
        if (instance == null)
            instance = new UI();

        return instance;
    }

    /**
     * private constructor. To create an instance of UI, call UI.getInstance() instead.
     */
    private UI() {


        setTitle("KidPaint");
        JPanel basePanel = new JPanel();
        getContentPane().add(basePanel, BorderLayout.CENTER);
        basePanel.setLayout(new BorderLayout(0, 0));

//        this.setTitle("KidPaint");


        paintPanel = new JPanel() {

            // refresh the paint panel
            @Override
            public void paint(Graphics g) {
                super.paint(g);

                Graphics2D g2 = (Graphics2D) g; // Graphics2D provides the setRenderingHints method

                // enable anti-aliasing
                RenderingHints rh = new RenderingHints(
                        RenderingHints.KEY_ANTIALIASING,
                        RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setRenderingHints(rh);

                // clear the paint panel using black
                g2.setColor(Color.black);
                g2.fillRect(0, 0, this.getWidth(), this.getHeight());
//                g2.setColor(Color.CYAN);

                // draw and fill circles with the specific colors stored in the data array
                for (int x = 0; x < data.length; x++) {
                    for (int y = 0; y < data[x].length; y++) {

                        g2.setColor(new Color(data[x][y]));
                        g2.fillArc(blockSize * x, blockSize * y, blockSize, blockSize, 0, 360);
                        g2.setColor(Color.darkGray);
                        g2.drawArc(blockSize * x, blockSize * y, blockSize, blockSize, 0, 360);
                    }
                }
            }
        };

        new Thread(() -> {
            receiveData();
        }).start();

        paintPanel.addMouseListener(new MouseListener() {
            @Override
            public void mouseClicked(MouseEvent e) {
            }

            @Override
            public void mouseEntered(MouseEvent e) {
            }

            @Override
            public void mouseExited(MouseEvent e) {
            }

            @Override
            public void mousePressed(MouseEvent e) {
            }

            // handle the mouse-up event of the paint panel
            @Override
            public void mouseReleased(MouseEvent e) {
                if (paintMode == PaintMode.Area && e.getX() >= 0 && e.getY() >= 0) {
                    int col = e.getX() / blockSize;
                    int row = e.getY() / blockSize;

                    new Thread(() -> {
                        sendData(col, row, selectedColor, 2, "");
                    }).start();


                    paintArea(col, row);
                }
            }
        });

        paintPanel.addMouseMotionListener(new MouseMotionListener() {

            @Override
            public void mouseDragged(MouseEvent e) {
                if (paintMode == PaintMode.Pixel && e.getX() >= 0 && e.getY() >= 0) {
                    int col = e.getX() / blockSize;
                    int row = e.getY() / blockSize;

                    new Thread(() -> {
                        sendData(col, row, selectedColor, 1, "");
                    }).start();

                    paintPixel(col, row);
                }
            }

            @Override
            public void mouseMoved(MouseEvent e) {
            }

        });

        paintPanel.setPreferredSize(new Dimension(data.length * blockSize, data[0].length * blockSize));

        JScrollPane scrollPaneLeft = new JScrollPane(paintPanel, JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED, JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);

        basePanel.add(scrollPaneLeft, BorderLayout.CENTER);

        JPanel toolPanel = new JPanel();
        basePanel.add(toolPanel, BorderLayout.NORTH);
        toolPanel.setLayout(new FlowLayout(FlowLayout.CENTER, 5, 5));

        pnlColorPicker = new JPanel();
        pnlColorPicker.setPreferredSize(new Dimension(24, 24));
        pnlColorPicker.setBackground(new Color(selectedColor));
//        pnlColorPicker.setBackground(Color.CYAN);
        pnlColorPicker.setBorder(new LineBorder(new Color(0, 0, 0)));

        // show the color picker
        pnlColorPicker.addMouseListener(new MouseListener() {
            @Override
            public void mouseClicked(MouseEvent e) {
            }

            @Override
            public void mouseEntered(MouseEvent e) {
            }

            @Override
            public void mouseExited(MouseEvent e) {
            }

            @Override
            public void mousePressed(MouseEvent e) {
            }

            @Override
            public void mouseReleased(MouseEvent e) {
                ColorPicker picker = ColorPicker.getInstance(UI.instance);
                Point location = pnlColorPicker.getLocationOnScreen();
                location.y += pnlColorPicker.getHeight();
                picker.setLocation(location);
                picker.setVisible(true);
            }

        });

        toolPanel.add(pnlColorPicker);

        tglPen = new JToggleButton("Pen");
        tglPen.setSelected(true);
        toolPanel.add(tglPen);

        tglBucket = new JToggleButton("Bucket");
        toolPanel.add(tglBucket);

        tglSave = new JToggleButton("Save");
        toolPanel.add(tglSave);

        tglLoad = new JToggleButton("Load");
        toolPanel.add(tglLoad);


        tglClearOnline = new JToggleButton("ClearOnline");
        toolPanel.add(tglClearOnline);

        tglpyramind1 = new JToggleButton("pyramind1");
        toolPanel.add(tglpyramind1);

        tglpyramind2 = new JToggleButton("pyramind2");
        toolPanel.add(tglpyramind2);

        tglsquare = new JToggleButton("square");
        toolPanel.add(tglsquare);
        // change the paint mode to PIXEL mode
        tglPen.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent arg0) {
                tglPen.setSelected(true);
                tglBucket.setSelected(false);
                tglSave.setSelected(false);
                tglLoad.setSelected(false);
                tglClearOnline.setSelected(false);
                tglpyramind1.setSelected(false);
                tglpyramind2.setSelected(false);
                paintMode = PaintMode.Pixel;
            }
        });

        // change the paint mode to AREA mode
        tglBucket.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent arg0) {
                tglPen.setSelected(false);
                tglBucket.setSelected(true);
                tglLoad.setSelected(false);
                tglSave.setSelected(false);
                tglClearOnline.setSelected(false);
                tglpyramind1.setSelected(false);
                tglpyramind2.setSelected(false);
                paintMode = PaintMode.Area;
            }
        });

        tglSave.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent arg0) {

                new Thread(() -> {
                    for (int row = 0; row < data.length; row++) {
                        for (int col = 0; col < data[row].length; col++) {
                            if (data[row][col] != 0)
                                sendData(row, col, data[row][col], 5, "");
                        }
                    }
                }).start();

                tglPen.setSelected(false);
                tglBucket.setSelected(false);
                tglLoad.setSelected(false);
                tglSave.setSelected(true);
                tglClearOnline.setSelected(false);
                tglpyramind1.setSelected(false);
                tglpyramind2.setSelected(false);
                paintMode = PaintMode.Area;
            }
        });

        tglLoad.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent arg0) {

//                new Thread(() -> {
                sendData(0, 0, 0, 4, "");
//                }).start();
                tglPen.setSelected(false);
                tglBucket.setSelected(false);
                tglLoad.setSelected(true);
                tglSave.setSelected(false);
                tglClearOnline.setSelected(false);
                tglpyramind1.setSelected(false);
                tglpyramind2.setSelected(false);
            }
        });

        tglClearOnline.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent arg0) {

                new Thread(() -> {
                    sendData(0, 0, 0, 6, "");
                }).start();

//

                tglPen.setSelected(false);
                tglBucket.setSelected(false);
                tglLoad.setSelected(false);
                tglSave.setSelected(false);
                tglClearOnline.setSelected(true);
                tglpyramind1.setSelected(false);
                tglpyramind2.setSelected(false);

            }
        });

        tglpyramind1.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent arg0) {

//                new Thread(() -> {
                sendData(0, 0, selectedColor, 7, "");
//                }).start();
                tglPen.setSelected(false);
                tglBucket.setSelected(false);
                tglLoad.setSelected(false);
                tglSave.setSelected(false);
                tglClearOnline.setSelected(false);
                tglpyramind1.setSelected(true);
                tglpyramind2.setSelected(false);
                tglsquare.setSelected(false);
            }
        });

        tglpyramind2.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent arg0) {

//                new Thread(() -> {
                sendData(0, 0, selectedColor, 8, "");
//                }).start();
                tglPen.setSelected(false);
                tglBucket.setSelected(false);
                tglLoad.setSelected(false);
                tglSave.setSelected(false);
                tglClearOnline.setSelected(false);
                tglpyramind1.setSelected(false);
                tglpyramind2.setSelected(true);
                tglsquare.setSelected(false);
            }
        });

        tglsquare.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent arg0) {

//                new Thread(() -> {
                sendData(0, 0, selectedColor, 9, "");
//                }).start();
                tglPen.setSelected(false);
                tglBucket.setSelected(false);
                tglLoad.setSelected(false);
                tglSave.setSelected(false);
                tglClearOnline.setSelected(false);
                tglpyramind1.setSelected(false);
                tglpyramind2.setSelected(false);
                tglsquare.setSelected(true);
            }
        });


        JPanel msgPanel = new JPanel();
        JPanel studioPanel = new JPanel();


        getContentPane().add(msgPanel, BorderLayout.EAST);
//        getContentPane().add(studioPanel, BorderLayout.SOUTH);

        studioPanel.setLayout(new BorderLayout(0, 0));
        msgPanel.setLayout(new BorderLayout(0, 0));

        msgField = new JTextField();// text field for inputting message
        msgField.setFont(new Font("", Font.PLAIN, 20));
        studioField = new JTextField();
        studioField.setFont(new Font("", Font.PLAIN, 20));

        msgPanel.add(msgField, BorderLayout.SOUTH);
        studioPanel.add(studioField,BorderLayout.SOUTH);
//        msgPanel.add(studioField,);
        // handle key-input event of the message field
        msgField.addKeyListener(new KeyListener() {
            @Override
            public void keyTyped(KeyEvent e) {
            }

            @Override
            public void keyPressed(KeyEvent e) {
            }

            @Override
            public void keyReleased(KeyEvent e) {
                if (e.getKeyCode() == 10) {// if the user press ENTER

//                    new Thread(() -> {
                    String record = msgField.getText();
                    sendData(0, 0, 0, 3, record);
//                    }).start();
//                    onTextInputted(msgField.getText());
                    msgField.setText("");
                }
            }

        });

        studioField.addKeyListener(new KeyListener() {
            @Override
            public void keyTyped(KeyEvent e) {
            }

            @Override
            public void keyPressed(KeyEvent e) {
            }

            @Override
            public void keyReleased(KeyEvent e) {
                if (e.getKeyCode() == 10) {// if the user press ENTER

//                    new Thread(() -> {
                    String record = studioField.getText();
                    sendData(0, 0, 0, 10, record);
//                    }).start();
//                    onTextInputted(msgField.getText());
                    studioField.setText("");
                }
            }

        });

        chatArea = new JTextArea();        // the read only text area for showing messages
        chatArea.setFont(new Font("", Font.PLAIN, 20));
        chatArea.setEditable(false);
        chatArea.setLineWrap(true);

        JScrollPane scrollPaneRight = new JScrollPane(chatArea, JScrollPane.VERTICAL_SCROLLBAR_ALWAYS, JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
        scrollPaneRight.setPreferredSize(new Dimension(300, this.getHeight()));
        msgPanel.add(scrollPaneRight, BorderLayout.CENTER);

        studio = new JTextArea();
        studio.setFont(new Font("", Font.PLAIN, 20));
        studio.setText("Please enter a studio name you want to join:");
        studio.setEditable(false);
        studio.setLineWrap(true);

        JScrollPane scrollPaneLeft1 = new JScrollPane(studio, JScrollPane.VERTICAL_SCROLLBAR_ALWAYS, JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
        scrollPaneLeft1.setPreferredSize(new Dimension(300, 300));
//        studioPanel.add(scrollPaneLeft1,BorderLayout.CENTER);
        studioPanel.add(scrollPaneLeft1, BorderLayout.CENTER);
        msgPanel.add(studioPanel, BorderLayout.NORTH);

        this.setSize(new Dimension(1000, 800));
        this.setLocationRelativeTo(null);
        this.setDefaultCloseOperation(EXIT_ON_CLOSE);
    }


    /**
     * it will be invoked if the user selected the specific color through the color picker
     *
     * @param colorValue - the selected color
     */
    public void selectColor(int colorValue) {
        SwingUtilities.invokeLater(() -> {
            selectedColor = colorValue;
            pnlColorPicker.setBackground(new Color(colorValue));
        });
    }


    /**
     * it will be invoked if the user inputted text in the message field
     *
     * @param text - user inputted text
     */
    private void onTextInputted(String text) {
        chatArea.setText(chatArea.getText() + text + "\n");
    }

    /**
     * change the color of a specific pixel
     *
     * @param col, row - the position of the selected pixel
     */
    public void paintPixel(int col, int row) {
        if (col >= data.length || row >= data[0].length) return;

        data[col][row] = selectedColor;
        paintPanel.repaint(col * blockSize, row * blockSize, blockSize, blockSize);
    }

    private void paintPixel1(int col, int row, int selectedColor) {
        if (col >= data.length || row >= data[0].length) return;

        data[col][row] = selectedColor;
        paintPanel.repaint(col * blockSize, row * blockSize, blockSize, blockSize);
    }

    private void sendData(int col, int row, int selectedColor, int tool, String msg) {

        try {

            KidPaint.out.writeInt(tool);

            if (tool == 7 || tool == 8 || tool == 9){
                KidPaint.out.writeInt(selectedColor);
            }else if (tool == 1 || tool == 2 || tool == 5) {

                KidPaint.out.writeInt(col);
                Thread.sleep(1);
                KidPaint.out.writeInt(row);
                Thread.sleep(1);
                KidPaint.out.writeInt(selectedColor);
//                Thread.sleep(1);
//            }
            } else if (tool == 3) {
//                msg = KidPaint.name + ":" + msg;
                String str = KidPaint.name + ": " + msg;
                System.out.println("msg:" + msg);
                byte[] chatData = str.getBytes();
                KidPaint.out.writeInt(str.length());
                KidPaint.out.write(chatData, 0, str.length());
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void receiveData() {
        try {
            while (true) {
                byte[] buffer = new byte[1024];
                int len = 0;
                int col = 0;
                int row = 0;
                int selectedColor = 0;
                int tool = KidPaint.in.readInt();
                Thread.sleep(1);

                if (tool == 1 || tool == 2) {
                    col = KidPaint.in.readInt();
                    Thread.sleep(1);
                    row = KidPaint.in.readInt();
                    Thread.sleep(1);
                    selectedColor = KidPaint.in.readInt();
                    Thread.sleep(1);

                } else if (tool == 3) {
                    len = KidPaint.in.readInt();
                    Thread.sleep(1);
                    KidPaint.in.read(buffer, 0, len);
                    Thread.sleep(1);
                }

                String chatRecord = new String(buffer, 0, len);


                if (tool == 1)
                    paintPixel1(col, row, selectedColor);
                else if (tool == 2)
                    paintArea1(col, row, selectedColor);
                else if (tool == 3)
                    onTextInputted(chatRecord);

            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * change the color of a specific area
     *
     * @param col, row - the position of the selected pixel
     * @return a list of modified pixels
     */
    public java.util.List paintArea(int col, int row) {
        LinkedList<Point> filledPixels = new LinkedList<Point>();

        if (col >= data.length || row >= data[0].length) return filledPixels;

        int oriColor = data[col][row];
        LinkedList<Point> buffer = new LinkedList<Point>();

        if (oriColor != selectedColor) {
            buffer.add(new Point(col, row));

            while (!buffer.isEmpty()) {
                Point p = buffer.removeFirst();
                int x = p.x;
                int y = p.y;

                if (data[x][y] != oriColor)
                    continue;

                data[x][y] = selectedColor;
                filledPixels.add(p);

                if (x > 0 && data[x - 1][y] == oriColor)
                    buffer.add(new Point(x - 1, y));

                if (x < data.length - 1 && data[x + 1][y] == oriColor)
                    buffer.add(new Point(x + 1, y));

                if (y > 0 && data[x][y - 1] == oriColor)
                    buffer.add(new Point(x, y - 1));

                if (y < data[0].length - 1 && data[x][y + 1] == oriColor)
                    buffer.add(new Point(x, y + 1));
            }
            paintPanel.repaint();
        }
        return filledPixels;
    }

    public List paintArea1(int col, int row, int selectedColor) {
        LinkedList<Point> filledPixels = new LinkedList<Point>();

        if (col >= data.length || row >= data[0].length) return filledPixels;

        int oriColor = data[col][row];
        LinkedList<Point> buffer = new LinkedList<Point>();

        if (oriColor != selectedColor) {
            buffer.add(new Point(col, row));

            while (!buffer.isEmpty()) {
                Point p = buffer.removeFirst();
                int x = p.x;
                int y = p.y;

                if (data[x][y] != oriColor)
                    continue;

                data[x][y] = selectedColor;
                filledPixels.add(p);

                if (x > 0 && data[x - 1][y] == oriColor)
                    buffer.add(new Point(x - 1, y));

                if (x < data.length - 1 && data[x + 1][y] == oriColor)
                    buffer.add(new Point(x + 1, y));

                if (y > 0 && data[x][y - 1] == oriColor)
                    buffer.add(new Point(x, y - 1));

                if (y < data[0].length - 1 && data[x][y + 1] == oriColor)
                    buffer.add(new Point(x, y + 1));
            }
            paintPanel.repaint();
        }
        return filledPixels;
    }

    /**
     * set pixel data and block size
     *
     * @param data
     * @param blockSize
     */
    public void setData(int[][] data, int blockSize) {
        this.data = data;
        this.blockSize = blockSize;
        paintPanel.setPreferredSize(new Dimension(data.length * blockSize, data[0].length * blockSize));
        paintPanel.repaint();
    }
}