import com.sun.javaws.IconUtil;
import com.sun.media.jfxmediaimpl.HostUtils;

import java.io.*;
import java.net.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.TreeMap;

public class Server {
    DatagramSocket socket;
    ServerSocket srvSocket;
    Socket clientSocket;

    String user;
    HashMap<Socket, String> clientMap = new HashMap<>();
    int[][] data;
    int[][] save;
    int col;
    int row;
    int tool;

    public Server() throws IOException {
        try {
            srvSocket = new ServerSocket(45678);
        } catch (IOException e) {
            e.printStackTrace();
        }
        data = new int[50][50];
        save = new int[50][50];


        InetAddress address = InetAddress.getLocalHost();
        socket = new DatagramSocket(45678);

        while (true) {
            System.out.printf("Listening at port %d...\n", 45678);

            DatagramPacket packet = new DatagramPacket(new byte[1024], 1024);
            socket.receive(packet);

            new Thread(() -> {
                Connecting(socket, packet);
            }).start();

            TCP();
        }

    }

    void Connecting(DatagramSocket socket, DatagramPacket packet) {
        byte[] data = packet.getData();

        user = new String(data, 0, packet.getLength());

        StringBuilder sb = new StringBuilder();

        String Client_IP = packet.getAddress().toString().substring(1);
        int Client_Port = packet.getPort();


        sb.append("IP:").append(Client_IP).append("\n")
                .append("Port:").append(Client_Port).append("\n")
                .append("Connecting....");

        byte[] buffer = sb.toString().getBytes();
        packet = new DatagramPacket(buffer, buffer.length, packet.getAddress(), Client_Port);

        try {
            socket.send(packet);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    void TCP() {

        try {
            clientSocket = srvSocket.accept();
        } catch (IOException e) {
            e.printStackTrace();
        }

        synchronized (clientMap) {

            clientMap.put(clientSocket, user);
            System.out.printf("Total %d clients are connected.\n", clientMap.size());

        }

        new Thread(() -> {
            try {
                serve(clientSocket);
            } catch (Exception e) {
                System.out.println("User: " + user + " is dropped.");
            }


            synchronized (clientMap) {
                clientMap.remove(clientSocket, user);

            }
        }).start();

    }

    private void serve(Socket clientSocket) throws Exception {

        System.out.printf("Established a connection to host %s %s:%d\n\n"
                , clientMap.get(clientSocket), clientSocket.getInetAddress().toString(), clientSocket.getPort());

        DataInputStream in = new DataInputStream(clientSocket.getInputStream());

        while (true) {
            byte[] buffer = new byte[1024];
            int len = 0;
            int selectedColor = 0;
            String chatData = "";
            tool = in.readInt();
            Thread.sleep(1);


            if (tool == 7 || tool == 8 || tool == 9){
                selectedColor = in.readInt();
                Thread.sleep(1);
            }else if (tool == 1 || tool == 2 || tool == 5) {

                col = in.readInt();
                Thread.sleep(1);
                row = in.readInt();
                Thread.sleep(1);
                selectedColor = in.readInt();
                Thread.sleep(1);
            } else if (tool == 3) {

                len = in.readInt();
                Thread.sleep(1);
                in.read(buffer, 0, len);
                Thread.sleep(1);
                chatData = new String(buffer, 0, len);
            }

            if (tool == 5) {

                save[col][row] = selectedColor;
                data[col][row] = selectedColor;
            }else if (tool == 4) {
                loadBackupData(clientSocket);

            } else if (tool == 1 || tool == 2 || tool == 3 || tool == 6 || tool == 7 || tool == 8 || tool == 9) {


                synchronized (clientMap) {
                    for (Socket socket : clientMap.keySet()) {
                        DataOutputStream out = new DataOutputStream(socket.getOutputStream());

                        if (tool == 9){

                            int finalSelectedColor = selectedColor;
                            new Thread(()->{
                                try {

                                    printSquare(out, finalSelectedColor);
                                } catch (IOException | InterruptedException e) {
                                    e.printStackTrace();
                                }
                            }).start();
                        }else if (tool == 8) {

                            int finalSelectedColor1 = selectedColor;
                            new Thread(()->{
                                try {
                                    printPyramid2(out, finalSelectedColor1);
                                } catch (IOException | InterruptedException e) {
                                    e.printStackTrace();
                                }
                            }).start();
                        }else if (tool == 7) {

                            int finalSelectedColor2 = selectedColor;
                            new Thread(()->{
                                try {
                                    printPyramid1(out, finalSelectedColor2);
                                } catch (IOException | InterruptedException e) {
                                    e.printStackTrace();
                                }

                            }).start();
                        } else if (tool == 6) {
                            new Thread(()->{
                                try {
                                    clearData(out);
                                } catch (IOException | InterruptedException e) {
                                    e.printStackTrace();
                                }
                            }).start();
                        }
                        else if (tool == 1 || tool == 2) {
                            out.writeInt(tool);
                            out.writeInt(col);
//                        Thread.sleep(500);
                            out.writeInt(row);
//                        Thread.sleep(500);
                            out.writeInt(selectedColor);
//                        Thread.sleep(500);
                        } else if (tool == 3) {
                            out.writeInt(tool);
                            byte[] data = chatData.getBytes();
                            out.writeInt(chatData.length());
                            out.write(data, 0, chatData.length());
                        }
                    }

                }
            }


        }
    }

    private void loadBackupData(Socket clientSocket) throws IOException, InterruptedException {
        DataOutputStream out = new DataOutputStream(clientSocket.getOutputStream());
        for (int col = 0; col < save.length; col++) {

            for (int row = 0; row < save[col].length; row++) {


                if (save[col][row] != 0) {

                    out.writeInt(1);
                    Thread.sleep(1);
                    out.writeInt(col);
                    Thread.sleep(1);
                    out.writeInt(row);
                    Thread.sleep(1);

                    out.writeInt(save[col][row]);
                    Thread.sleep(1);

                    data[col][row] = save[col][row];

                }

            }
        }
    }

    private void clearData(DataOutputStream out) throws IOException, InterruptedException {
        for (int col = 0; col < data.length; col++) {
            for (int row = 0; row < data[col].length; row++) {

                if (data[col][row] != 0) {
                    out.writeInt(1);
                    Thread.sleep(1);
                    out.writeInt(col);
                    Thread.sleep(1);
                    out.writeInt(row);
                    Thread.sleep(1);
                    out.writeInt(0);
                    Thread.sleep(1);
                    data[col][row] = 0;
                }



            }

        }
    }

    private void printPyramid1(DataOutputStream out, int selectedColor) throws IOException, InterruptedException {

        for (int col = 0; col < data.length - 20; col++) {

            for (int row = 0; row < col; row++) {

                    out.writeInt(1);
                    Thread.sleep(1);
                    out.writeInt(row);
                    Thread.sleep(1);
                    out.writeInt(col);
                    Thread.sleep(1);
                    out.writeInt(selectedColor);
                    Thread.sleep(1);
                    data[row][col] = selectedColor;

            }

        }
    }

    private void printPyramid2(DataOutputStream out, int selectedColor) throws IOException, InterruptedException {

        for (int col = 0; col < data.length - 20; col++) {
            for (int row = 0; row < col; row++) {

                if (data[col][row] == 0) {
                    out.writeInt(1);
                    Thread.sleep(1);
                    out.writeInt(col);
                    Thread.sleep(1);
                    out.writeInt(row);
                    Thread.sleep(1);
                    out.writeInt(selectedColor);
                    Thread.sleep(1);
                    data[col][row] = selectedColor;
                }

            }

        }
    }

    private void printSquare(DataOutputStream out,int selectedColor) throws IOException, InterruptedException {
        for (int col = 0; col < data.length - 20; col++) {
            for (int row = 0; row < data[col].length-20; row++) {

                if (data[col][row] == 0) {
                    out.writeInt(1);
                    Thread.sleep(1);
                    out.writeInt(col);
                    Thread.sleep(1);
                    out.writeInt(row);
                    Thread.sleep(1);
                    out.writeInt(selectedColor);
                    Thread.sleep(1);
                    data[col][row] = selectedColor;
                }

            }

        }
    }

    public static void main(String[] args) throws IOException {
        new Server();
    }
}
