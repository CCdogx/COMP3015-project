import javax.swing.*;
import java.awt.*;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.util.concurrent.atomic.AtomicReference;

public class Login extends JFrame {

    JPanel panel = new JPanel();
    JTextField userText;
    DatagramPacket packet;
    JTextArea textArea;
    DatagramSocket socket;

    public Login() {
        this.setTitle("KidPaint");
        this.setSize(new Dimension(400, 300));
        this.setLocationRelativeTo(null);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.add(panel);

        panel.setLayout(null);
        JLabel label = new JLabel("Enter your name");
        label.setBounds(10, 10, 300, 25);
        label.setFont(new Font("", Font.PLAIN, 25));
        panel.add(label);

        userText = new JTextField(20);
        userText.setBounds(10, 45, 210, 60);
        userText.setFont(new Font("", Font.PLAIN, 27));
        panel.add(userText);

        textArea = new JTextArea();
        textArea.setEditable(false);
        textArea.setBackground(Color.LIGHT_GRAY);
        textArea.setBounds(10, 120, 300, 100);
        textArea.setFont(new Font("", Font.PLAIN, 24));
        panel.add(textArea);

        AtomicReference<String> name = new AtomicReference<>("");
        JButton button = new JButton("Login");
        button.setBounds(260, 45, 100, 50);
        button.setFont(new Font("", Font.PLAIN, 20));
        button.addActionListener(e -> {

            name.set(userText.getText());
            if (!name.get().isEmpty()) {
                request(name.get());
            } else {
                name.set("Player");
                userText.setText(name.get());
                request(name.get());
            }
            new Thread(() -> {
                receive();
            }).start();
            button.setEnabled(false);

        });
        panel.add(button);

        userText.addKeyListener(new KeyListener() {

            @Override
            public void keyTyped(KeyEvent e) {
            }

            @Override
            public void keyPressed(KeyEvent e) {
            }

            @Override
            public void keyReleased(KeyEvent e) {
                if (e.getKeyCode() == 10) {

                    KidPaint.name = userText.getText();
                    if (!KidPaint.name.isEmpty()) {
                        request(KidPaint.name);
                    } else {
                        KidPaint.name = "Player";
                        userText.setText(KidPaint.name);
                        request(KidPaint.name);
                    }

                    new Thread(() -> {
                        receive();
                    }).start();
                    button.setEnabled(false);
//                    button.setSelected(false);
                }

            }
        });


        this.setVisible(true);

        try {
            Thread.sleep(6000);

        } catch (InterruptedException interruptedException) {
            interruptedException.printStackTrace();
        }

        if (textArea.getText().isEmpty() || KidPaint.Server_IP == null || KidPaint.Server_Port == 0) {
            textArea.setFont(new Font("", Font.PLAIN, 30));
            textArea.setText("Time is out......");

            try {
                Thread.sleep(1000);

            } catch (InterruptedException interruptedException) {
                interruptedException.printStackTrace();
            }
            System.exit(0);
        }

        this.dispose();
//        new KidPaint().runOnce();
    }

    private void request(String name) {
        try {
            socket = new DatagramSocket();
            byte[] buffer = name.getBytes();
            packet = new DatagramPacket(buffer, buffer.length, InetAddress.getByName("158.182.6.255"), 45678);
            socket.send(packet);
        } catch (IOException e) {
            System.err.println(e.getMessage());
        }
    }

    private void receive() {
        StringBuilder sb = new StringBuilder();
        try {

            packet = new DatagramPacket(new byte[1024], 1024);
            socket.receive(packet);
            KidPaint.Server_IP = packet.getAddress().toString().substring(1);
            KidPaint.Server_Port = packet.getPort();
            sb.append("Server IP:").append(KidPaint.Server_IP).append("\n")
                    .append("Server Port:").append(KidPaint.Server_Port).append("\n")
                    .append("Connecting the server....");
        } catch (IOException k) {
            System.out.println(k.getMessage());
        }

        textArea.append(sb.toString());
    }
}
