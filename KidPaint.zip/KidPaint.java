import javax.imageio.ImageIO;
import javax.swing.*;
import javax.swing.border.LineBorder;
import java.awt.*;
import java.awt.event.*;
import java.awt.image.BufferedImage;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.IOException;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.util.LinkedList;
import java.util.List;
import java.util.concurrent.atomic.AtomicReference;

public class KidPaint {
    public static Socket socket;
    public static String Server_IP;
    public static int Server_Port;
    public static DataOutputStream out;
    public static DataInputStream in;
    protected static String name;

    public static void main(String[] args) {
        new Login();

        new KidPaint().runOnce();
    }

    void runOnce() {
        try {
            KidPaint.socket = new Socket(Server_IP, Server_Port);
            out = new DataOutputStream(KidPaint.socket.getOutputStream());
            in = new DataInputStream(KidPaint.socket.getInputStream());
        } catch (IOException ignored) {
            System.exit(0);
        }

        UI ui = UI.getInstance();            // get the instance of UI
        ui.setData(new int[50][50], 20);    // set the data array and block size. comment this statement to use the default data array and block size.
        ui.setVisible(true);                // set the ui
    }


}








